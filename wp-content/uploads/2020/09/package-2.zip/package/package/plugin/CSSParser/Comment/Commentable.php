<?php

namespace Sabberworm\CSS\Comment;

interface Commentable
{
    public function addComments(array $aComments);
    public function getComments();
    public function setComments(array $aComments);
}
